<template>
  <div  :class="{'unchecked': !checked, 'checked': checked}"
        @click="toggleIt"></div>
</template>

<script>
/* eslint-disable no-console */
export default {
    data () {
        return {
            checked: false
        }
    },
    props: ['toggle'],
    name: 'Cell',
    mounted() {
        this.checked = this.toggle
    },
    methods: {
        toggleIt: function () {
            this.checked = !this.checked
        }
    }
}
</script>

<style scoped>
div {
  width: 100%;
  height: 100%;
  border-style: solid;
}
.checked {
    background-color: black;
    border-color: white;
}
.unchecked {
    background-color: white;
    border-color: black;
}
</style>
