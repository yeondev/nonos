<template>
  <div>
    <table style="background:black">
      <tr>
          <td><Cell toggle=false /></td>
          <td><Cell /></td>
          <td><Cell /></td>
          <td><Cell /></td>
      </tr>
    </table>
  </div>
</template>

<script>
/* eslint-disable no-console */
import Cell from './Cell.vue'

export default {
    data () {
        return {
        }
    },
    components: {
        Cell
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
td {
    width: 20px;
    height: 20px;
    border-style: none;
    padding:0; margin:0;
}
</style>
